﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace ANZHFR.Data.Models
{
    public partial class Hospital
    {
        public string Location
        {
            get
            {
                string location = this.HCountry;

                if (!string.IsNullOrWhiteSpace(this.HSuburb) && !string.IsNullOrWhiteSpace(this.HState) && !string.IsNullOrWhiteSpace(this.HCountry))
                {
                    location = string.Format("{0}, {1}, {2}", this.HSuburb, this.HState, this.HCountry);
                }
                else if (!string.IsNullOrWhiteSpace(this.HState) && !string.IsNullOrWhiteSpace(this.HCountry))
                {
                    location = string.Format("{0}, {1}", this.HState, this.HCountry);
                }

                return location;
            }
        }
    }

    public partial class Survey
    {
        public static int GetYear()
        {
            return GetYear(DateTime.Now);
        }

        public static int GetYear(DateTime baseDate)
        {
            DateTime calcDate = Convert.ToDateTime(ConfigurationManager.AppSettings["SurveyStartDate"]);
            DateTime surveyStartDate = new DateTime(baseDate.Year, calcDate.Month, calcDate.Day);

            int year = DateTime.Now.Year;

            if (baseDate < surveyStartDate)
            {
                year--;
            }

            return year;
        }

        public static string GetYearText(int year)
        {
            return GetYearText(new DateTime(year, 1, 1));
        }

        public static string GetYearText()
        {
            return GetYearText(DateTime.Now);
        }

        public static string GetYearText(DateTime baseDate)
        {
            int year = GetYear(baseDate);
            DateTime thisYear = new DateTime(year, 1, 1);
            DateTime nextYear = new DateTime(year + 1, 1, 1);

            return string.Format("{0:yyyy}/{1:yy}", thisYear, nextYear);
        }

        public int EstimatedNumberOfFractures
        {
            get
            {
                string estimateText = "";

                if (this.EstimatedRecords.Contains("-"))
                {
                    string[] values = this.EstimatedRecords.Split('-');
                    estimateText = values[1];
                }
                else if (this.EstimatedRecords.Contains("+"))
                {
                    estimateText = this.EstimatedRecords.Replace("+", "");
                }

                int estimate = 0;
                int.TryParse(estimateText, out estimate);

                return estimate;
            }
        }
    }

    public partial class Patient
    {
    }
}